# ApostaPro — Starter (Expo + TypeScript)

Este é um scaffold inicial do aplicativo **ApostaPro** (React Native + TypeScript via Expo).

## O que tem aqui
- Estrutura básica com telas: Login, Home, Analysis, Profile
- Navegação com React Navigation (stack)
- Cores base: preto (#0B0B0B), dourado (#D4AF37), branco (#FFFFFF)

## Como rodar localmente
1. Instale `node` (>=18) e `npm` ou `yarn`.
2. Instale Expo CLI globalmente (opcional): `npm install -g expo-cli`
3. No terminal:
   ```bash
   cd apostapro
   npm install
   npm start
   # ou
   yarn
   yarn start
   ```
4. Siga o QR code no Expo Go (Android/iOS) ou rode em emulador.

## Como criar repositório no GitHub e enviar o projeto
1. No GitHub, crie um novo repositório chamado `apostapro`.
2. No terminal:
   ```bash
   git init
   git add .
   git commit -m "Initial commit — ApostaPro starter"
   git branch -M main
   git remote add origin https://github.com/zielvrs/apostapro.git
   git push -u origin main
   ```
   > Substitua a URL se você criou com outro nome de usuário ou repo privado.

## Próximos passos que posso fazer pra você
- Subir este projeto diretamente para um repositório (preciso de acesso via invite/token).  
- Adicionar integração com autenticação (JWT), Stripe e backend de exemplo.  
- Gerar telas Figma com este visual.

Diga o que prefere: quer que eu gere e envie o repositório (você me dá as permissões) ou prefere eu te mandar o arquivo zip pra você subir? 
