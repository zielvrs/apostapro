export const COLORS = {
  background: '#0B0B0B',
  gold: '#D4AF37',
  white: '#FFFFFF'
};
