import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';

export default function ProfileScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Perfil</Text>
      <Text style={styles.text}>Assinatura: Free (demo)</Text>
      <Button title="Gerenciar assinatura" onPress={() => alert('Gerenciar (demo)')} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, alignItems:'center', justifyContent:'center', backgroundColor:'#0B0B0B' },
  title: { color:'#D4AF37', fontSize:24, marginBottom:8 },
  text: { color:'#FFFFFF', marginBottom:12 }
});
