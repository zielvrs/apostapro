import React from 'react';
import { View, Text, StyleSheet, ScrollView, Button } from 'react-native';

export default function AnalysisScreen({ route }: any) {
  const { gameId } = route.params || {};
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Análise do jogo #{gameId}</Text>
      <Text style={styles.excerpt}>Resumo rápido: time A vem em melhor forma, modelagem indica 55% de vitória.</Text>
      <View style={styles.block}>
        <Text style={styles.blockTitle}>Estatísticas</Text>
        <Text style={styles.blockText}>Posse de bola, xG, média de gols...</Text>
      </View>
      <View style={styles.block}>
        <Text style={styles.blockTitle}>Sugestão de aposta</Text>
        <Text style={styles.blockText}>Back Time A — odd 1.80 — stake recomendado: 5%</Text>
      </View>
      <Button title="Favoritar" onPress={() => alert('Favorito! (demo)')} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, padding:16, backgroundColor:'#0B0B0B' },
  title: { color:'#D4AF37', fontSize:22, marginBottom:8 },
  excerpt: { color:'#FFFFFF', marginBottom:12 },
  block: { backgroundColor:'#111111', padding:10, borderRadius:8, marginBottom:10 },
  blockTitle: { color:'#D4AF37', fontWeight:'600', marginBottom:6 },
  blockText: { color:'#FFFFFF' }
});
