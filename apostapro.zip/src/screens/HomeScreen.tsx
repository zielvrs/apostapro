import React from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet } from 'react-native';

const DATA = [
  { id: '1', teams: 'Corinthians x Palmeiras', time: '20:00', odds: '1.80 / 3.20 / 4.50' },
  { id: '2', teams: 'Flamengo x Vasco', time: '21:30', odds: '1.60 / 3.50 / 5.00' },
];

export default function HomeScreen({ navigation }: any) {
  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Jogos em destaque</Text>
      <FlatList
        data={DATA}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.card} onPress={() => navigation.navigate('Analysis', { gameId: item.id })}>
            <Text style={styles.teams}>{item.teams}</Text>
            <Text style={styles.meta}>{item.time} • {item.odds}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex:1, padding:16, backgroundColor: '#0B0B0B' },
  heading: { color:'#D4AF37', fontSize:20, marginBottom:12 },
  card: { backgroundColor: '#111111', padding:12, borderRadius:8, marginBottom:10 },
  teams: { color:'#FFFFFF', fontSize:16, marginBottom:4 },
  meta: { color:'#CCCCCC', fontSize:12 }
});
