Replace these with your logo (icon.png) and splash image (splash.png).
Icon: 1024x1024 PNG recommended.
Splash: 1242x2436 or responsive image.
